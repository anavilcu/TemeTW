function addTokens(input, tokens){
    if(input.length<6){
        throw new Error("Input should have at least 6 characters")
    }

    if(typeof(input)!=='string'){

        throw new Error("Invalid input")
    }

    for (let index=0;index<tokens.length;index++){
        if(typeof(tokens[index].tokenName)!=="string"){
            throw new Error("Invalid array format")
        }
    }

   

    for (let index=0;index<tokens.length;index++){
        token="${"+tokens[index].tokenName+"}"
        input=input.replace("...", token)
    }
    return input
}

const app = {
    addTokens: addTokens
}

module.exports = app;