const distance = (a, b) => {
	//TODO: implementați funcția
	// TODO: implement the function

	if((typeof(a)==='string' || (a instanceof String)) &&
	   (typeof(b)==='string' || (b instanceof String)))
	   {
		const mat = []

		for (let i=0;i<a.length+1;i++){
			const rand=[]
			for(let j=0;j<b.length+1;j++){
				rand.push(j)
			}
		
			rand[0]=i;
			mat.push(rand)
		
		}
		
		for (let i=1;i<a.length+1;i++){
			for(let j=1;j<b.length+1;j++){
				if(a[i-1]===b[j-1]){
					mat[i][j]=mat[i-1][j-1]
				}
				else{
					mat[i][j]=1+Math.min(mat[i-1][j-1],mat[i-1][j],mat[i][j-1])
				}
			}
		
			
		}
		
		
		return mat[a.length][b.length]
	   }
	   else
	   {
			throw new Error("InvalidType")
	
		}
	

	
}


module.exports.distance = distance